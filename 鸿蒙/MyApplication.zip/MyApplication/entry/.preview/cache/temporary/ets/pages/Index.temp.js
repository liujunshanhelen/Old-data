var _76918e5a108bf3e3a917545f085b6552;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "E:\\temp\\MyApplication\\entry\\src\\main\\ets\\pages\\Index.ets?entry":
/*!**********************************************************************!*\
  !*** E:\temp\MyApplication\entry\src\main\ets\pages\Index.ets?entry ***!
  \**********************************************************************/
/***/ (function(__unused_webpack_module, exports) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
let __generate__Id = 0;
function generateId() {
    return "Index_" + ++__generate__Id;
}
var _ohos_net_http_1  = globalThis.requireNapi('net.http') || (isSystemplugin('net.http', 'ohos') ? globalThis.ohosplugin.net.http : isSystemplugin('net.http', 'system') ? globalThis.systemplugin.net.http : undefined);
var _ohos_router_1  = globalThis.requireNapi('router') || (isSystemplugin('router', 'ohos') ? globalThis.ohosplugin.router : isSystemplugin('router', 'system') ? globalThis.systemplugin.router : undefined);
class Index extends View {
    constructor(compilerAssignedUniqueChildId, parent, params, localStorage) {
        super(compilerAssignedUniqueChildId, parent, localStorage);
        this.__movieList = new ObservedPropertyObject([], this, "movieList");
        this.updateWithValueParams(params);
    }
    updateWithValueParams(params) {
        if (params.movieList !== undefined) {
            this.movieList = params.movieList;
        }
    }
    aboutToBeDeleted() {
        this.__movieList.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id());
    }
    get movieList() {
        return this.__movieList.get();
    }
    set movieList(newValue) {
        this.__movieList.set(newValue);
    }
    aboutToAppear() {
        _ohos_net_http_1.createHttp().request('http://172.17.205.111:8080/hit/DoubanServlet?type=movie', (err, data) => {
            if (!err) {
                let t = JSON.parse(data.result.toString());
                this.movieList = t.subjects;
            }
        });
    }
    render() {
        Row.create();
        Row.debugLine("pages/Index.ets(23:5)");
        Row.height('100%');
        Row.backgroundColor(Color.Green);
        Column.create();
        Column.debugLine("pages/Index.ets(24:7)");
        Column.width('100%');
        Column.height('100%');
        Column.backgroundColor(Color.Pink);
        List.create({ space: 20, initialIndex: 0 });
        List.debugLine("pages/Index.ets(25:9)");
        List.width('100%');
        List.height('100%');
        ForEach.create("2", this, ObservedObject.GetRawObject(this.movieList), (item) => {
            ListItem.create();
            ListItem.debugLine("pages/Index.ets(27:13)");
            ListItem.onClick(() => {
                _ohos_router_1.pushUrl({
                    url: 'pages/Login',
                    params: {
                        url: item.url
                    }
                });
            });
            Row.create();
            Row.debugLine("pages/Index.ets(28:15)");
            Text.create(item.title);
            Text.debugLine("pages/Index.ets(29:17)");
            Text.fontSize(20);
            Text.pop();
            Text.create(item.url);
            Text.debugLine("pages/Index.ets(30:17)");
            Text.fontSize(20);
            Text.pop();
            Row.pop();
            ListItem.pop();
        }, item => item.id);
        ForEach.pop();
        List.pop();
        Column.pop();
        Row.pop();
    }
}
loadDocument(new Index("1", undefined, {}));


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["E:\\temp\\MyApplication\\entry\\src\\main\\ets\\pages\\Index.ets?entry"](0, __webpack_exports__);
/******/ 	_76918e5a108bf3e3a917545f085b6552 = __webpack_exports__;
/******/ 	
/******/ })()
;
//# sourceMappingURL=Index.js.map