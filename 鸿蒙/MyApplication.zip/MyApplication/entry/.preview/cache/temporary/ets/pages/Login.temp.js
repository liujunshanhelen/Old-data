var _76918e5a108bf3e3a917545f085b6552;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "E:\\temp\\MyApplication\\entry\\src\\main\\ets\\pages\\Login.ets?entry":
/*!**********************************************************************!*\
  !*** E:\temp\MyApplication\entry\src\main\ets\pages\Login.ets?entry ***!
  \**********************************************************************/
/***/ (function(__unused_webpack_module, exports) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
let __generate__Id = 0;
function generateId() {
    return "Login_" + ++__generate__Id;
}
var _ohos_web_webview_1  = globalThis.requireNapi('web.webview') || (isSystemplugin('web.webview', 'ohos') ? globalThis.ohosplugin.web.webview : isSystemplugin('web.webview', 'system') ? globalThis.systemplugin.web.webview : undefined);
var _ohos_router_1  = globalThis.requireNapi('router') || (isSystemplugin('router', 'ohos') ? globalThis.ohosplugin.router : isSystemplugin('router', 'system') ? globalThis.systemplugin.router : undefined);
class Index extends View {
    constructor(compilerAssignedUniqueChildId, parent, params, localStorage) {
        super(compilerAssignedUniqueChildId, parent, localStorage);
        this.controller = new _ohos_web_webview_1.WebviewController();
        this.url = _ohos_router_1.getParams()['url'];
        this.updateWithValueParams(params);
    }
    updateWithValueParams(params) {
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
        if (params.url !== undefined) {
            this.url = params.url;
        }
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id());
    }
    render() {
        Column.create();
        Column.debugLine("pages/Login.ets(10:5)");
        Column.width('100%');
        Column.height('100%');
        Web.create({ src: this.url, controller: this.controller });
        Web.debugLine("pages/Login.ets(11:7)");
        Web.width('100%');
        Web.height('90%');
        Row.create();
        Row.debugLine("pages/Login.ets(14:7)");
        Button.createWithLabel('后退');
        Button.debugLine("pages/Login.ets(15:9)");
        Button.onClick(() => {
            this.controller.backward();
        });
        Button.pop();
        Button.createWithLabel('前进');
        Button.debugLine("pages/Login.ets(19:9)");
        Button.onClick(() => {
            this.controller.forward();
        });
        Button.pop();
        Row.pop();
        Column.pop();
    }
}
loadDocument(new Index("1", undefined, {}));


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["E:\\temp\\MyApplication\\entry\\src\\main\\ets\\pages\\Login.ets?entry"](0, __webpack_exports__);
/******/ 	_76918e5a108bf3e3a917545f085b6552 = __webpack_exports__;
/******/ 	
/******/ })()
;
//# sourceMappingURL=Login.js.map