var _6511a0f984086915793e543c5d06e724;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "C:\\Users\\Admin\\DevecostudioProjects\\HarmonyMovie\\entry\\src\\main\\ets\\pages\\Index.ets?entry":
/*!*************************************************************************************************!*\
  !*** C:\Users\Admin\DevecostudioProjects\HarmonyMovie\entry\src\main\ets\pages\Index.ets?entry ***!
  \*************************************************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
let __generate__Id = 0;
function generateId() {
    return "Index_" + ++__generate__Id;
}
var _ohos_router_1  = globalThis.requireNapi('router') || (isSystemplugin('router', 'ohos') ? globalThis.ohosplugin.router : isSystemplugin('router', 'system') ? globalThis.systemplugin.router : undefined);
const movie_1 = __importDefault(__webpack_require__(/*! ./objects/movie */ "C:\\Users\\Admin\\DevecostudioProjects\\HarmonyMovie\\entry\\src\\main\\ets\\pages\\objects\\movie.ts"));
var _ohos_net_http_1  = globalThis.requireNapi('net.http') || (isSystemplugin('net.http', 'ohos') ? globalThis.ohosplugin.net.http : isSystemplugin('net.http', 'system') ? globalThis.systemplugin.net.http : undefined);
class Index extends View {
    constructor(compilerAssignedUniqueChildId, parent, params, localStorage) {
        super(compilerAssignedUniqueChildId, parent, localStorage);
        this.__httpRequest = new ObservedPropertyObject(_ohos_net_http_1.createHttp(), this, "httpRequest");
        this.__movies = new ObservedPropertyObject([], this, "movies");
        this.updateWithValueParams(params);
    }
    updateWithValueParams(params) {
        if (params.httpRequest !== undefined) {
            this.httpRequest = params.httpRequest;
        }
        if (params.movies !== undefined) {
            this.movies = params.movies;
        }
    }
    aboutToBeDeleted() {
        this.__httpRequest.aboutToBeDeleted();
        this.__movies.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id());
    }
    get httpRequest() {
        return this.__httpRequest.get();
    }
    set httpRequest(newValue) {
        this.__httpRequest.set(newValue);
    }
    get movies() {
        return this.__movies.get();
    }
    set movies(newValue) {
        this.__movies.set(newValue);
    }
    onPageShow() {
        if (parseInt(_ohos_router_1.getLength()) > 1)
            _ohos_router_1.clear();
    }
    async aboutToAppear() {
        let p = this.httpRequest.request("http://172.17.205.111:8080/hit/DoubanServlet?type=movie");
        await p.then((data) => {
            if (typeof data.result === 'string') {
                let t = JSON.parse(data.result);
                for (let i = 0; i < t.subjects.length; i++) {
                    let item = t.subjects[i];
                    let tmp_movie = new movie_1.default(parseFloat(item.rate) / 2, item.title, item.url, item.cover, item.id);
                    this.movies.push(tmp_movie);
                }
            }
            else {
                console.info("Error");
            }
        });
    }
    render() {
        Row.create();
        Row.debugLine("pages/Index.ets(32:5)");
        Row.height('100%');
        Row.width('100%');
        Column.create();
        Column.debugLine("pages/Index.ets(33:7)");
        Column.width('100%');
        Text.create('豆瓣热门电影');
        Text.debugLine("pages/Index.ets(34:9)");
        Text.fontSize(40);
        Text.fontWeight(FontWeight.Bold);
        Text.margin({ top: 25 });
        Text.pop();
        List.create({ space: 20, initialIndex: 0 });
        List.debugLine("pages/Index.ets(39:9)");
        List.height('85%');
        List.width('90%');
        List.margin({ top: 20 });
        List.lanes(2);
        ForEach.create("3", this, ObservedObject.GetRawObject(this.movies), (item) => {
            ListItem.create();
            ListItem.debugLine("pages/Index.ets(41:13)");
            ListItem.height(250);
            ListItem.onClick(() => {
                _ohos_router_1.pushUrl({
                    url: 'pages/Detail',
                    params: {
                        url: item.url
                    }
                });
            });
            Column.create();
            Column.debugLine("pages/Index.ets(42:15)");
            Column.margin({ left: 5, right: 5 });
            Image.create(item.cover);
            Image.debugLine("pages/Index.ets(43:17)");
            Image.height('90%');
            Row.create();
            Row.debugLine("pages/Index.ets(44:17)");
            Row.justifyContent(FlexAlign.SpaceBetween);
            Text.create(item.title);
            Text.debugLine("pages/Index.ets(45:19)");
            Text.height('10%');
            Text.width('60%');
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
            Text.fontSize(16);
            Text.pop();
            Rating.create({ rating: item.rate, indicator: true });
            Rating.debugLine("pages/Index.ets(51:19)");
            Rating.stepSize(0.1);
            Rating.width('40%');
            Rating.pop();
            Row.pop();
            Column.pop();
            ListItem.pop();
        }, item => item.id);
        ForEach.pop();
        List.pop();
        Column.pop();
        Row.pop();
    }
}
loadDocument(new Index("2", undefined, {}));


/***/ }),

/***/ "C:\\Users\\Admin\\DevecostudioProjects\\HarmonyMovie\\entry\\src\\main\\ets\\pages\\objects\\movie.ts":
/*!**************************************************************************************************!*\
  !*** C:\Users\Admin\DevecostudioProjects\HarmonyMovie\entry\src\main\ets\pages\objects\movie.ts ***!
  \**************************************************************************************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
class movie {
    constructor(rate, title, url, cover, id) {
        this.rate = rate;
        this.title = title;
        this.url = url;
        this.cover = cover;
        this.id = id;
    }
}
exports["default"] = movie;


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		var commonCachedModule = globalThis["__common_module_cache___6511a0f984086915793e543c5d06e724"] ? globalThis["__common_module_cache___6511a0f984086915793e543c5d06e724"][moduleId]: null;
/******/ 		if (commonCachedModule) { return commonCachedModule.exports; }
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		function isCommonModue(moduleId) {
/******/ 		                if (globalThis["webpackChunk_6511a0f984086915793e543c5d06e724"]) {
/******/ 		                  const length = globalThis["webpackChunk_6511a0f984086915793e543c5d06e724"].length;
/******/ 		                  switch (length) {
/******/ 		                    case 1:
/******/ 		                      return globalThis["webpackChunk_6511a0f984086915793e543c5d06e724"][0][1][moduleId];
/******/ 		                    case 2:
/******/ 		                      return globalThis["webpackChunk_6511a0f984086915793e543c5d06e724"][0][1][moduleId] ||
/******/ 		                      globalThis["webpackChunk_6511a0f984086915793e543c5d06e724"][1][1][moduleId];
/******/ 		                  }
/******/ 		                }
/******/ 		                return undefined;
/******/ 		              }
/******/ 		if (globalThis["__common_module_cache___6511a0f984086915793e543c5d06e724"] && String(moduleId).indexOf("?name=") < 0 && isCommonModue(moduleId)) {
/******/ 		  globalThis["__common_module_cache___6511a0f984086915793e543c5d06e724"][moduleId] = module;
/******/ 		}
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__("C:\\Users\\Admin\\DevecostudioProjects\\HarmonyMovie\\entry\\src\\main\\ets\\pages\\Index.ets?entry");
/******/ 	_6511a0f984086915793e543c5d06e724 = __webpack_exports__;
/******/ 	
/******/ })()
;
//# sourceMappingURL=Index.js.map