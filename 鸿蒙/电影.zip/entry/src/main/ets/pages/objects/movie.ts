class movie
{
    rate: null;
    title: null;
    url: null;
    cover: null;
    id: null;
    constructor(rate, title, url, cover, id) {
        this.rate = rate;
        this.title = title;
        this.url = url;
        this.cover = cover;
        this.id = id;
    }
}

export default movie;