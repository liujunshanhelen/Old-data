var _6511a0f984086915793e543c5d06e724;
/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "C:\\Users\\Admin\\DevecostudioProjects\\HarmonyMovie\\entry\\src\\main\\ets\\pages\\Detail.ets?entry":
/*!**************************************************************************************************!*\
  !*** C:\Users\Admin\DevecostudioProjects\HarmonyMovie\entry\src\main\ets\pages\Detail.ets?entry ***!
  \**************************************************************************************************/
/***/ (() => {

throw new Error("Module parse failed: Unexpected character ',' (62:26)\nFile was processed with these loaders:\n * ./lib/result_process.js\n * ./node_modules/ts-loader/index.js\n * ./lib/pre_process.js\nYou may need an additional loader to handle the result of these loaders.\n|         Button.height('5%');\n|         Button.backgroundColor(0xFFFFFF);\n>         Button.fontColor(#, 9, D9E9F);\n|         Button.pop();\n|         Blank.create();");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module doesn't tell about it's top-level declarations so it can't be inlined
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["C:\\Users\\Admin\\DevecostudioProjects\\HarmonyMovie\\entry\\src\\main\\ets\\pages\\Detail.ets?entry"]();
/******/ 	_6511a0f984086915793e543c5d06e724 = __webpack_exports__;
/******/ 	
/******/ })()
;
//# sourceMappingURL=Detail.js.map