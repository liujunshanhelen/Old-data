var _3a4ded664851909acb9e6497578a39cd;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "../../../../../../../../../Desktop/new/harmonybetterweather/entry/src/main/ets/pages/Index.ets?entry":
/*!************************************************************************************************************!*\
  !*** ../../../../../../../../../Desktop/new/harmonybetterweather/entry/src/main/ets/pages/Index.ets?entry ***!
  \************************************************************************************************************/
/***/ (function(__unused_webpack_module, exports) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
let __generate__Id = 0;
function generateId() {
    return "Index_" + ++__generate__Id;
}
var _ohos_data_preferences_1  = globalThis.requireNapi('data.preferences') || (isSystemplugin('data.preferences', 'ohos') ? globalThis.ohosplugin.data.preferences : isSystemplugin('data.preferences', 'system') ? globalThis.systemplugin.data.preferences : undefined);
var _ohos_router_1  = globalThis.requireNapi('router') || (isSystemplugin('router', 'ohos') ? globalThis.ohosplugin.router : isSystemplugin('router', 'system') ? globalThis.systemplugin.router : undefined);
var _ohos_net_http_1  = globalThis.requireNapi('net.http') || (isSystemplugin('net.http', 'ohos') ? globalThis.ohosplugin.net.http : isSystemplugin('net.http', 'system') ? globalThis.systemplugin.net.http : undefined);
class Index extends View {
    constructor(compilerAssignedUniqueChildId, parent, params, localStorage) {
        super(compilerAssignedUniqueChildId, parent, localStorage);
        this.settings = new RenderingContextSettings(true);
        this.context1 = new CanvasRenderingContext2D(this.settings);
        this.context2 = new CanvasRenderingContext2D(this.settings);
        this.httpRequest = _ohos_net_http_1.createHttp();
        this.preference = null;
        this.__ready = new ObservedPropertySimple(false, this, "ready");
        this.__text = new ObservedPropertySimple("", this, "text");
        this.__scrolly = new ObservedPropertySimple(0, this, "scrolly");
        this.__trans = new ObservedPropertySimple(1, this, "trans");
        this.__aqi_colors = new ObservedPropertyObject([0x00FF2F, 0xFFE400, 0xFFA644], this, "aqi_colors");
        this.__city = new ObservedPropertySimple("", this, "city");
        this.__now_temp = new ObservedPropertySimple(0, this, "now_temp");
        this.__now_weather = new ObservedPropertySimple("", this, "now_weather");
        this.__now_aqi = new ObservedPropertySimple(0, this, "now_aqi");
        this.__now_aqi_level = new ObservedPropertySimple("", this, "now_aqi_level");
        this.__now_aqi_color = new ObservedPropertySimple(0x0000FF, this, "now_aqi_color");
        this.__future_list = new ObservedPropertyObject([], this, "future_list");
        this.__future_list_max = new ObservedPropertyObject({ min: 0, max: 30 }, this, "future_list_max");
        this.__hour_list = new ObservedPropertyObject([], this, "hour_list");
        this.__hour_list_max = new ObservedPropertyObject({ min: 0, max: 30 }, this, "hour_list_max");
        this.updateWithValueParams(params);
    }
    updateWithValueParams(params) {
        if (params.settings !== undefined) {
            this.settings = params.settings;
        }
        if (params.context1 !== undefined) {
            this.context1 = params.context1;
        }
        if (params.context2 !== undefined) {
            this.context2 = params.context2;
        }
        if (params.httpRequest !== undefined) {
            this.httpRequest = params.httpRequest;
        }
        if (params.preference !== undefined) {
            this.preference = params.preference;
        }
        if (params.ready !== undefined) {
            this.ready = params.ready;
        }
        if (params.text !== undefined) {
            this.text = params.text;
        }
        if (params.scrolly !== undefined) {
            this.scrolly = params.scrolly;
        }
        if (params.trans !== undefined) {
            this.trans = params.trans;
        }
        if (params.aqi_colors !== undefined) {
            this.aqi_colors = params.aqi_colors;
        }
        if (params.city !== undefined) {
            this.city = params.city;
        }
        if (params.now_temp !== undefined) {
            this.now_temp = params.now_temp;
        }
        if (params.now_weather !== undefined) {
            this.now_weather = params.now_weather;
        }
        if (params.now_aqi !== undefined) {
            this.now_aqi = params.now_aqi;
        }
        if (params.now_aqi_level !== undefined) {
            this.now_aqi_level = params.now_aqi_level;
        }
        if (params.now_aqi_color !== undefined) {
            this.now_aqi_color = params.now_aqi_color;
        }
        if (params.future_list !== undefined) {
            this.future_list = params.future_list;
        }
        if (params.future_list_max !== undefined) {
            this.future_list_max = params.future_list_max;
        }
        if (params.hour_list !== undefined) {
            this.hour_list = params.hour_list;
        }
        if (params.hour_list_max !== undefined) {
            this.hour_list_max = params.hour_list_max;
        }
    }
    aboutToBeDeleted() {
        this.__ready.aboutToBeDeleted();
        this.__text.aboutToBeDeleted();
        this.__scrolly.aboutToBeDeleted();
        this.__trans.aboutToBeDeleted();
        this.__aqi_colors.aboutToBeDeleted();
        this.__city.aboutToBeDeleted();
        this.__now_temp.aboutToBeDeleted();
        this.__now_weather.aboutToBeDeleted();
        this.__now_aqi.aboutToBeDeleted();
        this.__now_aqi_level.aboutToBeDeleted();
        this.__now_aqi_color.aboutToBeDeleted();
        this.__future_list.aboutToBeDeleted();
        this.__future_list_max.aboutToBeDeleted();
        this.__hour_list.aboutToBeDeleted();
        this.__hour_list_max.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id());
    }
    get ready() {
        return this.__ready.get();
    }
    set ready(newValue) {
        this.__ready.set(newValue);
    }
    get text() {
        return this.__text.get();
    }
    set text(newValue) {
        this.__text.set(newValue);
    }
    get scrolly() {
        return this.__scrolly.get();
    }
    set scrolly(newValue) {
        this.__scrolly.set(newValue);
    }
    get trans() {
        return this.__trans.get();
    }
    set trans(newValue) {
        this.__trans.set(newValue);
    }
    get aqi_colors() {
        return this.__aqi_colors.get();
    }
    set aqi_colors(newValue) {
        this.__aqi_colors.set(newValue);
    }
    get city() {
        return this.__city.get();
    }
    set city(newValue) {
        this.__city.set(newValue);
    }
    get now_temp() {
        return this.__now_temp.get();
    }
    set now_temp(newValue) {
        this.__now_temp.set(newValue);
    }
    get now_weather() {
        return this.__now_weather.get();
    }
    set now_weather(newValue) {
        this.__now_weather.set(newValue);
    }
    get now_aqi() {
        return this.__now_aqi.get();
    }
    set now_aqi(newValue) {
        this.__now_aqi.set(newValue);
    }
    get now_aqi_level() {
        return this.__now_aqi_level.get();
    }
    set now_aqi_level(newValue) {
        this.__now_aqi_level.set(newValue);
    }
    get now_aqi_color() {
        return this.__now_aqi_color.get();
    }
    set now_aqi_color(newValue) {
        this.__now_aqi_color.set(newValue);
    }
    get future_list() {
        return this.__future_list.get();
    }
    set future_list(newValue) {
        this.__future_list.set(newValue);
    }
    get future_list_max() {
        return this.__future_list_max.get();
    }
    set future_list_max(newValue) {
        this.__future_list_max.set(newValue);
    }
    get hour_list() {
        return this.__hour_list.get();
    }
    set hour_list(newValue) {
        this.__hour_list.set(newValue);
    }
    get hour_list_max() {
        return this.__hour_list_max.get();
    }
    set hour_list_max(newValue) {
        this.__hour_list_max.set(newValue);
    }
    async getPreferencesFromStorage() {
        let context = getContext(this);
        this.preference = await _ohos_data_preferences_1.getPreferences(context, "better_weather");
    }
    async setPreference(name, data) {
        if (this.preference !== null) {
            await this.preference.put(name, data);
            await this.preference.flush();
        }
    }
    async getPreference(name) {
        if (this.preference !== null) {
            let tmp = await this.preference.get(name, "");
            return tmp;
        }
        return null;
    }
    async aboutToAppear() {
        await this.getPreferencesFromStorage();
        try {
            this.city = _ohos_router_1.getParams()['city'];
        }
        catch (_) {
            let tmp = await this.getPreference("fav");
            if (tmp === null || tmp === "") {
                tmp = await this.getPreference("cities");
                console.warn(tmp);
                if (tmp !== null && tmp.length > 0)
                    this.city = JSON.parse(tmp)[0];
                else {
                    this.city = "北京";
                    await this.setPreference("cities", JSON.stringify(["北京"]));
                    await this.setPreference("fav", "北京");
                }
            }
            else {
                this.city = tmp;
            }
        }
        let p = this.httpRequest.request("https://qqlykm.cn/api/weatherv2/get?key=SKWfR51mhdePUKJuvD57r3nBWW&city=" + this.city);
        await p.then((data) => {
            if (typeof data.result === 'string') {
                let t = JSON.parse(data.result.replace("15dayweather", "future"));
                if (t.success === true) {
                    this.now_temp = t.data.realtime.temp;
                    this.now_weather = t.data.realtime.weather;
                    this.now_aqi = t.data.realtime.aqi;
                    this.now_aqi_level = t.data.realtime.aqiLevelInfo;
                    if (t.data.realtime.aqiLevelInfo === "优")
                        this.now_aqi_color = this.aqi_colors[0];
                    else if (t.data.realtime.aqiLevelInfo === "良")
                        this.now_aqi_color = this.aqi_colors[1];
                    else
                        this.now_aqi_color = this.aqi_colors[2];
                    this.future_list = []; //15dayweather
                    let max = -100;
                    let min = 100;
                    //future_list
                    for (let i = 0; i < 5; i++) {
                        let tmp = { name: "", date: "", day_weather: "", night_weather: "", low: 0, high: 0, aqi: "" };
                        tmp.name = t.data.future[i].timeText;
                        tmp.date = t.data.future[i].date;
                        tmp.day_weather = t.data.future[i].dayWeather;
                        tmp.night_weather = t.data.future[i].nightWeather;
                        tmp.high = t.data.future[i].dayTemp;
                        tmp.low = t.data.future[i].nightTemp;
                        tmp.aqi = t.data.future[i].aqiLevelInfo;
                        if (tmp.low < min)
                            min = tmp.low;
                        if (tmp.high > max)
                            max = tmp.high;
                        this.future_list.push(tmp);
                    }
                    this.future_list_max.max = max;
                    this.future_list_max.min = min;
                    this.hour_list = []; //hourlyweather
                    //hour_list
                    for (let i = 0; i < 5; i++) {
                        let tmp = { name: "", weather: "", temp: 0 };
                        tmp.name = t.data.hourlyweather[i].timeText;
                        tmp.weather = t.data.hourlyweather[i].Weather;
                        let temp_str = t.data.hourlyweather[i].temp;
                        temp_str = temp_str.substring(0, temp_str.length - 1);
                        let temp = parseInt(temp_str);
                        if (temp === NaN)
                            temp = 0;
                        tmp.temp = temp;
                        if (temp < min)
                            min = temp;
                        if (temp > max)
                            max = temp;
                        this.hour_list.push(tmp);
                    }
                    this.hour_list_max.max = max;
                    this.hour_list_max.min = min;
                }
            }
            else {
                console.info("Error");
                return;
            }
        });
        console.warn("OOk");
        this.ready = true;
    }
    render() {
        If.create();
        if (this.ready) {
            If.branchId(0);
            Row.create();
            Row.debugLine("pages/Index.ets(154:7)");
            Row.backgroundColor(0xFFDBEB);
            Column.create();
            Column.debugLine("pages/Index.ets(155:9)");
            Column.width('100%');
            Column.justifyContent(FlexAlign.Start);
            Column.alignItems(HorizontalAlign.Start);
            Row.create();
            Row.debugLine("pages/Index.ets(156:11)");
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceBetween);
            Row.opacity(this.trans);
            Text.create(this.city);
            Text.debugLine("pages/Index.ets(157:13)");
            Text.fontSize(26);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Color.Black);
            Text.margin({ top: 10, left: 20 });
            Text.pop();
            Button.createWithChild();
            Button.debugLine("pages/Index.ets(163:13)");
            Button.width(45);
            Button.height(45);
            Button.margin({ top: 10, right: 20 });
            Button.backgroundColor(0xFFDBEB);
            Button.onClick((_) => {
                _ohos_router_1.pushUrl({
                    url: 'pages/City',
                    params: {}
                }).catch(err => {
                    console.error(`pushUrl failed, code is ${err.code}, message is ${err.message}`);
                });
            });
            Image.create({ "id": 16777224, "type": 20000, params: [], "bundleName": "work.twradio.betterweather", "moduleName": "entry" });
            Image.debugLine("pages/Index.ets(164:15)");
            Image.width(40);
            Image.height(40);
            Button.pop();
            Row.pop();
            Scroll.create();
            Scroll.debugLine("pages/Index.ets(185:13)");
            Scroll.width('100%');
            Scroll.scrollable(ScrollDirection.Vertical);
            Scroll.scrollBar(BarState.Off);
            Scroll.edgeEffect(EdgeEffect.Spring);
            Scroll.onScroll((_, y) => {
                this.scrolly += y;
                if (this.scrolly > 100)
                    this.trans = 1 - this.scrolly / 1000;
                else
                    this.trans = 1;
            });
            Column.create();
            Column.debugLine("pages/Index.ets(186:15)");
            Row.create();
            Row.debugLine("pages/Index.ets(188:17)");
            Row.width('100%');
            Row.height(400);
            Row.alignItems(VerticalAlign.Bottom);
            //当前时刻天气开始
            Column.create();
            Column.debugLine("pages/Index.ets(191:19)");
            //当前时刻天气开始
            Column.width(180);
            //当前时刻天气开始
            Column.height(130);
            //当前时刻天气开始
            Column.alignItems(HorizontalAlign.Start);
            Text.create(this.now_temp.toString() + "°");
            Text.debugLine("pages/Index.ets(192:21)");
            Text.fontColor(Color.White);
            Text.fontSize(55);
            Text.fontWeight(FontWeight.Bold);
            Text.margin({ left: 10 });
            Text.pop();
            Text.create(this.now_weather);
            Text.debugLine("pages/Index.ets(197:21)");
            Text.fontColor(Color.White);
            Text.fontSize(23);
            Text.margin({ left: 10 });
            Text.pop();
            Text.create("空气质量 - " + this.now_aqi);
            Text.debugLine("pages/Index.ets(201:21)");
            Text.fontColor(Color.White);
            Text.fontSize(18);
            Text.margin({ left: 10 });
            Text.pop();
            //当前时刻天气开始
            Column.pop();
            Row.pop();
            //当前时刻天气结束
            Blank.create();
            Blank.debugLine("pages/Index.ets(213:17)");
            //当前时刻天气结束
            Blank.height(5);
            //当前时刻天气结束
            Blank.pop();
            //每日概览卡片开始
            Column.create();
            Column.debugLine("pages/Index.ets(217:17)");
            //每日概览卡片开始
            Column.width('92%');
            //每日概览卡片开始
            Column.height(340);
            //每日概览卡片开始
            Column.alignItems(HorizontalAlign.Start);
            //每日概览卡片开始
            Column.border({ radius: 10, color: Color.White });
            //每日概览卡片开始
            Column.backgroundColor(Color.White);
            //每日概览卡片开始
            Column.opacity(0.9);
            Text.create("每日概览");
            Text.debugLine("pages/Index.ets(218:19)");
            Text.fontSize(18);
            Text.fontColor(0x2B85FF);
            Text.fontWeight(FontWeight.Bold);
            Text.margin({ top: 10, left: 15 });
            Text.pop();
            Column.create();
            Column.debugLine("pages/Index.ets(224:19)");
            Column.width('90%');
            Column.height(270);
            Column.alignSelf(ItemAlign.Center);
            Column.margin({ top: 20 });
            //概览上侧
            List.create();
            List.debugLine("pages/Index.ets(226:21)");
            //概览上侧
            List.width('100%');
            //概览上侧
            List.height(70);
            //概览上侧
            List.listDirection(Axis.Horizontal);
            ForEach.create("2", this, ObservedObject.GetRawObject(new Array(this.future_list.length).fill(1).map((_, index) => {
                return index;
            })), (item) => {
                ListItem.create();
                ListItem.debugLine("pages/Index.ets(230:25)");
                ListItem.width('20%');
                Column.create();
                Column.debugLine("pages/Index.ets(231:27)");
                Text.create(this.future_list[item].name);
                Text.debugLine("pages/Index.ets(232:29)");
                Text.fontSize(16);
                Text.pop();
                Blank.create();
                Blank.debugLine("pages/Index.ets(233:29)");
                Blank.height(5);
                Blank.pop();
                Text.create(this.future_list[item].date);
                Text.debugLine("pages/Index.ets(234:29)");
                Text.fontSize(15);
                Text.fontColor(Color.Grey);
                Text.pop();
                Blank.create();
                Blank.debugLine("pages/Index.ets(235:29)");
                Blank.height(7);
                Blank.pop();
                Text.create(this.future_list[item].day_weather);
                Text.debugLine("pages/Index.ets(236:29)");
                Text.fontSize(17);
                Text.fontColor(0x2B85FF);
                Text.pop();
                Column.pop();
                ListItem.pop();
            }, item => item);
            ForEach.pop();
            //概览上侧
            List.pop();
            If.create();
            //概览曲线
            if (this.future_list.length > 0) {
                If.branchId(0);
                Canvas.create(this.context1);
                Canvas.debugLine("pages/Index.ets(245:23)");
                Canvas.width('100%');
                Canvas.height(150);
                Canvas.onReady(() => {
                    let height = 30;
                    let width = 35;
                    let mid = 75;
                    let scale = height * 2 / (this.future_list_max.max - this.future_list_max.min);
                    let medium = (this.future_list_max.max + this.future_list_max.min) / 2;
                    this.context1.lineWidth = 4;
                    this.context1.lineJoin = 'miter';
                    this.context1.strokeStyle = 'rgb(43,133,255)'; //#2B85FF
                    this.context1.beginPath();
                    this.context1.moveTo(width, mid - scale * (this.future_list[0].high - medium));
                    for (let i = 1; i < 5; i++) {
                        this.context1.lineTo(width * 2 * i + width, mid - scale * (this.future_list[i].high - medium));
                    }
                    this.context1.stroke();
                    this.context1.closePath();
                    this.context1.font = '45px sans-serif';
                    this.context1.textAlign = 'center';
                    for (let i = 0; i < 5; i++) {
                        this.context1.fillText(this.future_list[i].high.toString() + '°', width * 2 * i + width, mid - scale * (this.future_list[i].high - medium) - 7);
                    }
                    this.context1.beginPath();
                    this.context1.strokeStyle = 'rgb(117,203,255)'; //#75CBFF
                    this.context1.moveTo(width, mid - scale * (this.future_list[0].low - medium));
                    for (let i = 1; i < 5; i++) {
                        this.context1.lineTo(width * 2 * i + width, mid - scale * (this.future_list[i].low - medium));
                    }
                    this.context1.stroke();
                    this.context1.closePath();
                    this.context1.font = '45px sans-serif';
                    this.context1.textAlign = 'center';
                    for (let i = 0; i < 5; i++) {
                        this.context1.fillText(this.future_list[i].low.toString() + '°', width * 2 * i + width, mid - scale * (this.future_list[i].low - medium) + 18);
                    }
                });
                Canvas.margin({ top: 5, bottom: 15 });
                Canvas.pop();
            }
            If.pop();
            //概览下侧
            List.create();
            List.debugLine("pages/Index.ets(293:21)");
            //概览下侧
            List.width('100%');
            //概览下侧
            List.height(25);
            //概览下侧
            List.listDirection(Axis.Horizontal);
            ForEach.create("3", this, ObservedObject.GetRawObject(new Array(this.future_list.length).fill(1).map((_, index) => {
                return index;
            })), (item) => {
                ListItem.create();
                ListItem.debugLine("pages/Index.ets(297:25)");
                ListItem.width('20%');
                Column.create();
                Column.debugLine("pages/Index.ets(298:27)");
                Text.create(this.future_list[item].night_weather);
                Text.debugLine("pages/Index.ets(299:29)");
                Text.fontSize(17);
                Text.fontColor(0x2B85FF);
                Text.pop();
                Column.pop();
                ListItem.pop();
            }, item => item);
            ForEach.pop();
            //概览下侧
            List.pop();
            Column.pop();
            //每日概览卡片开始
            Column.pop();
            //每日概览卡片结束
            Blank.create();
            Blank.debugLine("pages/Index.ets(320:17)");
            //每日概览卡片结束
            Blank.height(10);
            //每日概览卡片结束
            Blank.pop();
            //小时概览卡片开始
            Column.create();
            Column.debugLine("pages/Index.ets(323:17)");
            //小时概览卡片开始
            Column.width('92%');
            //小时概览卡片开始
            Column.height(220);
            //小时概览卡片开始
            Column.alignItems(HorizontalAlign.Start);
            //小时概览卡片开始
            Column.border({ radius: 10, color: Color.White });
            //小时概览卡片开始
            Column.backgroundColor(Color.White);
            //小时概览卡片开始
            Column.opacity(0.9);
            Text.create("小时概览");
            Text.debugLine("pages/Index.ets(324:19)");
            Text.fontSize(18);
            Text.fontColor(0x2B85FF);
            Text.fontWeight(FontWeight.Bold);
            Text.margin({ top: 10, left: 15 });
            Text.pop();
            Column.create();
            Column.debugLine("pages/Index.ets(330:19)");
            Column.width('90%');
            Column.height(200);
            Column.alignSelf(ItemAlign.Center);
            Column.margin({ top: 20 });
            //小时上侧
            List.create();
            List.debugLine("pages/Index.ets(332:21)");
            //小时上侧
            List.width('100%');
            //小时上侧
            List.height(50);
            //小时上侧
            List.listDirection(Axis.Horizontal);
            ForEach.create("4", this, ObservedObject.GetRawObject(new Array(this.hour_list.length).fill(1).map((_, index) => {
                return index;
            })), (item) => {
                ListItem.create();
                ListItem.debugLine("pages/Index.ets(336:25)");
                ListItem.width('20%');
                Column.create();
                Column.debugLine("pages/Index.ets(337:27)");
                Text.create(this.hour_list[item].name);
                Text.debugLine("pages/Index.ets(338:29)");
                Text.fontSize(16);
                Text.pop();
                Blank.create();
                Blank.debugLine("pages/Index.ets(339:29)");
                Blank.height(7);
                Blank.pop();
                Text.create(this.hour_list[item].weather);
                Text.debugLine("pages/Index.ets(340:29)");
                Text.fontSize(17);
                Text.fontColor(0x2B85FF);
                Text.pop();
                Column.pop();
                ListItem.pop();
            }, item => item);
            ForEach.pop();
            //小时上侧
            List.pop();
            If.create();
            //小时曲线
            if (this.hour_list.length > 0) {
                If.branchId(0);
                Canvas.create(this.context2);
                Canvas.debugLine("pages/Index.ets(349:23)");
                Canvas.width('100%');
                Canvas.height(100);
                Canvas.onReady(() => {
                    let height = 15;
                    let width = 35;
                    let mid = 50;
                    let scale = height * 2 / (this.hour_list_max.max - this.hour_list_max.min);
                    let medium = (this.hour_list_max.max + this.hour_list_max.min) / 2;
                    this.context2.restore();
                    this.context2.lineWidth = 4;
                    this.context2.lineJoin = 'miter';
                    this.context2.strokeStyle = 'rgb(43,133,255)'; //#2B85FF
                    this.context2.beginPath();
                    this.context2.moveTo(width, mid - scale * (this.hour_list[0].temp - medium));
                    for (let i = 1; i < 5; i++) {
                        this.context2.lineTo(width * 2 * i + width, mid - scale * (this.hour_list[i].temp - medium));
                    }
                    this.context2.stroke();
                    this.context2.closePath();
                    this.context2.font = '45px sans-serif';
                    this.context2.textAlign = 'center';
                    for (let i = 0; i < 5; i++) {
                        this.context2.fillText(this.hour_list[i].temp.toString() + '°', width * 2 * i + width, mid - scale * (this.hour_list[i].temp - medium) - 7);
                    }
                });
                Canvas.margin({ top: 0, bottom: 15 });
                Canvas.pop();
            }
            If.pop();
            Column.pop();
            //小时概览卡片开始
            Column.pop();
            //小时概览卡片结束
            Blank.create();
            Blank.debugLine("pages/Index.ets(396:17)");
            //小时概览卡片结束
            Blank.height(10);
            //小时概览卡片结束
            Blank.pop();
            //空气质量卡片开始
            Column.create();
            Column.debugLine("pages/Index.ets(400:17)");
            //空气质量卡片开始
            Column.width('92%');
            //空气质量卡片开始
            Column.height(200);
            //空气质量卡片开始
            Column.alignItems(HorizontalAlign.Start);
            //空气质量卡片开始
            Column.border({ radius: 10, color: Color.White });
            //空气质量卡片开始
            Column.backgroundColor(Color.White);
            //空气质量卡片开始
            Column.opacity(0.9);
            Text.create("空气质量");
            Text.debugLine("pages/Index.ets(401:19)");
            Text.fontSize(18);
            Text.fontColor(0x2B85FF);
            Text.fontWeight(FontWeight.Bold);
            Text.margin({ top: 10, left: 15 });
            Text.pop();
            Row.create();
            Row.debugLine("pages/Index.ets(406:19)");
            Row.width('90%');
            Row.height(170);
            Row.justifyContent(FlexAlign.SpaceBetween);
            Progress.create({ value: this.now_aqi, total: 400, type: ProgressType.Ring });
            Progress.debugLine("pages/Index.ets(407:21)");
            Progress.width(150);
            Progress.alignSelf(ItemAlign.Center);
            Progress.margin({ left: 10 });
            Progress.style({ strokeWidth: 15 });
            Progress.color(this.now_aqi_color);
            Text.create(this.now_aqi_level);
            Text.debugLine("pages/Index.ets(413:21)");
            Text.fontSize(18);
            Text.fontColor(0x758089);
            Text.fontWeight(FontWeight.Bold);
            Text.textAlign(TextAlign.Center);
            Text.position({ x: 10, y: 10 });
            Text.width(150);
            Text.height(150);
            Text.alignSelf(ItemAlign.Center);
            Text.pop();
            //空气质量左侧
            List.create();
            List.debugLine("pages/Index.ets(424:21)");
            //空气质量左侧
            List.width('35%');
            //空气质量左侧
            List.height(140);
            //空气质量左侧
            List.margin({ left: 10 });
            ForEach.create("5", this, ObservedObject.GetRawObject(new Array(this.future_list.length).fill(1).map((_, index) => {
                return index;
            })), (item) => {
                ListItem.create();
                ListItem.debugLine("pages/Index.ets(428:25)");
                ListItem.alignSelf(ItemAlign.Center);
                Column.create();
                Column.debugLine("pages/Index.ets(429:27)");
                Column.alignSelf(ItemAlign.Center);
                Row.create();
                Row.debugLine("pages/Index.ets(430:29)");
                Row.justifyContent(FlexAlign.SpaceBetween);
                Text.create(this.future_list[item].name + " ：  ");
                Text.debugLine("pages/Index.ets(431:31)");
                Text.fontSize(19);
                Text.fontColor(0x4E5767);
                Text.textAlign(TextAlign.Center);
                Text.pop();
                If.create();
                if (this.future_list[item].aqi == "优") {
                    If.branchId(0);
                    Text.create("优");
                    Text.debugLine("pages/Index.ets(434:33)");
                    Text.fontSize(22);
                    Text.fontColor(this.aqi_colors[0]);
                    Text.textAlign(TextAlign.Center);
                    Text.pop();
                }
                else if (this.future_list[item].aqi == "良") {
                    If.branchId(1);
                    Text.create("良");
                    Text.debugLine("pages/Index.ets(437:33)");
                    Text.fontSize(22);
                    Text.fontColor(this.aqi_colors[1]);
                    Text.textAlign(TextAlign.Center);
                    Text.pop();
                }
                else {
                    If.branchId(2);
                    Text.create(this.future_list[item].aqi);
                    Text.debugLine("pages/Index.ets(440:33)");
                    Text.fontSize(22);
                    Text.fontColor(this.aqi_colors[2]);
                    Text.textAlign(TextAlign.Center);
                    Text.pop();
                }
                If.pop();
                Row.pop();
                Blank.create();
                Blank.debugLine("pages/Index.ets(444:29)");
                Blank.height(3);
                Blank.pop();
                Column.pop();
                ListItem.pop();
            }, item => item);
            ForEach.pop();
            //空气质量左侧
            List.pop();
            Row.pop();
            //空气质量卡片开始
            Column.pop();
            Text.create("Powered by qqlykm.cn");
            Text.debugLine("pages/Index.ets(461:17)");
            Text.height(30);
            Text.fontSize(14);
            Text.pop();
            Blank.create();
            Blank.debugLine("pages/Index.ets(462:17)");
            Blank.height(60);
            Blank.pop();
            Column.pop();
            Scroll.pop();
            Column.pop();
            Row.pop();
        }
        If.pop();
    }
}
loadDocument(new Index("1", undefined, {}));


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["../../../../../../../../../Desktop/new/harmonybetterweather/entry/src/main/ets/pages/Index.ets?entry"](0, __webpack_exports__);
/******/ 	_3a4ded664851909acb9e6497578a39cd = __webpack_exports__;
/******/ 	
/******/ })()
;
//# sourceMappingURL=Index.js.map