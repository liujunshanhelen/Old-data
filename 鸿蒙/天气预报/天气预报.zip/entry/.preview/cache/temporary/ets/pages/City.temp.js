var _3a4ded664851909acb9e6497578a39cd;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "../../../../../../../../../Desktop/new/harmonybetterweather/entry/src/main/ets/Func.ts":
/*!**********************************************************************************************!*\
  !*** ../../../../../../../../../Desktop/new/harmonybetterweather/entry/src/main/ets/Func.ts ***!
  \**********************************************************************************************/
/***/ (function(__unused_webpack_module, exports) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
var _ohos_promptAction_1  = globalThis.requireNapi('promptAction') || (isSystemplugin('promptAction', 'ohos') ? globalThis.ohosplugin.promptAction : isSystemplugin('promptAction', 'system') ? globalThis.systemplugin.promptAction : undefined);
function showToast(msg, time = 2000) {
    try {
        _ohos_promptAction_1.showToast({
            message: msg,
            duration: time,
        });
    }
    catch (error) {
        console.error(`showToast args error code is ${error.code}, message is ${error.message}`);
    }
    ;
}
exports["default"] = { showToast };


/***/ }),

/***/ "../../../../../../../../../Desktop/new/harmonybetterweather/entry/src/main/ets/pages/City.ets?entry":
/*!***********************************************************************************************************!*\
  !*** ../../../../../../../../../Desktop/new/harmonybetterweather/entry/src/main/ets/pages/City.ets?entry ***!
  \***********************************************************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
let __generate__Id = 0;
function generateId() {
    return "City_" + ++__generate__Id;
}
var _ohos_data_preferences_1  = globalThis.requireNapi('data.preferences') || (isSystemplugin('data.preferences', 'ohos') ? globalThis.ohosplugin.data.preferences : isSystemplugin('data.preferences', 'system') ? globalThis.systemplugin.data.preferences : undefined);
var _ohos_router_1  = globalThis.requireNapi('router') || (isSystemplugin('router', 'ohos') ? globalThis.ohosplugin.router : isSystemplugin('router', 'system') ? globalThis.systemplugin.router : undefined);
var _ohos_net_http_1  = globalThis.requireNapi('net.http') || (isSystemplugin('net.http', 'ohos') ? globalThis.ohosplugin.net.http : isSystemplugin('net.http', 'system') ? globalThis.systemplugin.net.http : undefined);
const Func_1 = __importDefault(__webpack_require__(/*! ../Func */ "../../../../../../../../../Desktop/new/harmonybetterweather/entry/src/main/ets/Func.ts"));
class City extends View {
    constructor(compilerAssignedUniqueChildId, parent, params, localStorage) {
        super(compilerAssignedUniqueChildId, parent, localStorage);
        this.color = [Color.Pink];
        this.httpRequest = _ohos_net_http_1.createHttp();
        this.__ready = new ObservedPropertySimple(false, this, "ready");
        this.__message = new ObservedPropertySimple('Hello World', this, "message");
        this.__selected = new ObservedPropertySimple("七台河", this, "selected");
        this.__cities = new ObservedPropertyObject(["七台河", "哈尔滨"], this, "cities");
        this.__input = new ObservedPropertySimple("", this, "input");
        this.__city_info = new ObservedPropertyObject([], this, "city_info");
        this.preference = null;
        this.updateWithValueParams(params);
    }
    updateWithValueParams(params) {
        if (params.color !== undefined) {
            this.color = params.color;
        }
        if (params.httpRequest !== undefined) {
            this.httpRequest = params.httpRequest;
        }
        if (params.ready !== undefined) {
            this.ready = params.ready;
        }
        if (params.message !== undefined) {
            this.message = params.message;
        }
        if (params.selected !== undefined) {
            this.selected = params.selected;
        }
        if (params.cities !== undefined) {
            this.cities = params.cities;
        }
        if (params.input !== undefined) {
            this.input = params.input;
        }
        if (params.city_info !== undefined) {
            this.city_info = params.city_info;
        }
        if (params.preference !== undefined) {
            this.preference = params.preference;
        }
    }
    aboutToBeDeleted() {
        this.__ready.aboutToBeDeleted();
        this.__message.aboutToBeDeleted();
        this.__selected.aboutToBeDeleted();
        this.__cities.aboutToBeDeleted();
        this.__input.aboutToBeDeleted();
        this.__city_info.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id());
    }
    get ready() {
        return this.__ready.get();
    }
    set ready(newValue) {
        this.__ready.set(newValue);
    }
    get message() {
        return this.__message.get();
    }
    set message(newValue) {
        this.__message.set(newValue);
    }
    get selected() {
        return this.__selected.get();
    }
    set selected(newValue) {
        this.__selected.set(newValue);
    }
    get cities() {
        return this.__cities.get();
    }
    set cities(newValue) {
        this.__cities.set(newValue);
    }
    get input() {
        return this.__input.get();
    }
    set input(newValue) {
        this.__input.set(newValue);
    }
    get city_info() {
        return this.__city_info.get();
    }
    set city_info(newValue) {
        this.__city_info.set(newValue);
    }
    async getPreferencesFromStorage() {
        let context = getContext(this);
        this.preference = await _ohos_data_preferences_1.getPreferences(context, "better_weather");
    }
    async setPreference(name, data) {
        if (this.preference !== null) {
            await this.preference.put(name, data);
            await this.preference.flush();
        }
    }
    async getPreference(name) {
        if (this.preference !== null) {
            let tmp = await this.preference.get(name, "");
            return tmp;
        }
        return null;
    }
    test(index) {
        console.error(index);
        console.error(typeof this.city_info);
        console.error(this.city_info.length.toString());
        console.error(this.city_info[index].name);
        return true;
    }
    getCityInfo(index) {
        if (index < this.city_info.length)
            return this.city_info[index];
        else
            return { name: "", weather: "", low: 0, high: 0, describe: "", selected: false, exist: false };
    }
    async aboutToAppear() {
        await this.getPreferencesFromStorage();
        var tmp = await this.getPreference("cities");
        this.selected = await this.getPreference("fav");
        console.warn(tmp);
        if (tmp !== null && tmp !== "") {
            this.cities = JSON.parse(tmp);
        }
        else {
            await this.setPreference("cities", JSON.stringify(["北京"]));
            this.cities = ["北京"];
        }
        let max = this.cities.length;
        for (let i = 0; i < max; i++) {
            let city = this.cities[i];
            let p = this.httpRequest.request("https://qqlykm.cn/api/weatherv2/get?key=SKWfR51mhdePUKJuvD57r3nBWW&city=" + city);
            await p.then((data) => {
                if (typeof data.result === 'string') {
                    let t = JSON.parse(data.result.replace("15dayweather", "future"));
                    if (t.success === true) {
                        if (t.data !== null) {
                            if (t.data.areaName !== city) {
                                this.cities[i] = t.data.areaName;
                            }
                            let tmp = { name: t.data.areaName, weather: "", low: 0, high: 0, describe: "", selected: false, exist: true };
                            tmp.weather = t.data.realtime.weather;
                            tmp.describe = t.data.realtime.RainDescribe;
                            tmp.low = t.data.future[1].nightTemp;
                            tmp.high = t.data.future[1].dayTemp;
                            tmp.selected = (this.selected === city);
                            this.city_info.push(tmp);
                        }
                        else {
                            this.cities.splice(i--, 1);
                            max--;
                            Func_1.default.showToast("该城市不存在!");
                        }
                    }
                    else {
                        console.info("Error");
                        this.cities.splice(i--, 1);
                        max--;
                        Func_1.default.showToast("该城市不存在!");
                        return;
                    }
                }
            });
        }
        let notSelected = true;
        for (let city of this.city_info) {
            if (city.selected) {
                notSelected = false;
                break;
            }
        }
        if (notSelected) {
            this.city_info[0].selected = true;
            this.selected = this.cities[0];
            await this.setPreference("fav", this.selected);
        }
        await this.setPreference("cities", JSON.stringify(this.cities));
        this.ready = true;
    }
    render() {
        Row.create();
        Row.debugLine("pages/City.ets(136:5)");
        Row.height('100%');
        Column.create();
        Column.debugLine("pages/City.ets(137:7)");
        Column.width('100%');
        Column.height('100%');
        Column.justifyContent(FlexAlign.Start);
        Column.alignItems(HorizontalAlign.Start);
        Row.create();
        Row.debugLine("pages/City.ets(138:9)");
        Row.backgroundColor(0xFFDBEB);
        Row.height('9%');
        Row.width('100%');
        Image.create({ "id": 16777221, "type": 20000, params: [], "bundleName": "work.twradio.betterweather", "moduleName": "entry" });
        Image.debugLine("pages/City.ets(139:11)");
        Image.width(28);
        Image.height(28);
        Image.margin({ left: 10, top: 10 });
        TextInput.create({ text: this.input, placeholder: "输入一个地址" });
        TextInput.debugLine("pages/City.ets(140:11)");
        TextInput.enabled(this.ready);
        TextInput.maxLength(20);
        TextInput.width('85%');
        TextInput.backgroundColor(Color.White);
        TextInput.margin({ left: 8, top: 10 });
        TextInput.onChange((value) => {
            this.input = value;
        });
        TextInput.onSubmit((_) => {
            if (this.input !== null && typeof this.input === "string" && this.input !== "") {
                this.cities.push(this.input);
                this.setPreference("cities", JSON.stringify(ObservedObject.GetRawObject(this.cities))).then(async () => {
                    this.city_info = [];
                    this.ready = false;
                    await this.aboutToAppear();
                });
            }
            else {
                Func_1.default.showToast("请输入城市名称!");
            }
        });
        Row.pop();
        If.create();
        if (this.ready && this.city_info != undefined) {
            If.branchId(0);
            List.create();
            List.debugLine("pages/City.ets(165:11)");
            List.width('100%');
            List.height('90%');
            List.divider({ strokeWidth: 1, color: 0x222222FF });
            ForEach.create("2", this, ObservedObject.GetRawObject(new Array(this.city_info.length).fill(1).map((_, index) => {
                return index;
            })), (item) => {
                //if(item < this.city_info.length && this.getCityInfo(item).exist === true)
                ListItem.create();
                ListItem.debugLine("pages/City.ets(171:17)");
                //if(item < this.city_info.length && this.getCityInfo(item).exist === true)
                ListItem.width('100%');
                //if(item < this.city_info.length && this.getCityInfo(item).exist === true)
                ListItem.backgroundColor(this.color[this.getCityInfo(item).selected ? 1 : 0]);
                //if(item < this.city_info.length && this.getCityInfo(item).exist === true)
                ListItem.onClick(() => {
                    this.setPreference("fav", this.getCityInfo(item).name).then();
                    if (this.getCityInfo(item).exist) {
                        _ohos_router_1.clear();
                        _ohos_router_1.replaceUrl({
                            url: 'pages/Index',
                            params: {
                                city: this.getCityInfo(item).name
                            }
                        }).catch(err => {
                            console.error(`pushUrl failed, code is ${err.code}, message is ${err.message}`);
                        });
                    }
                    else {
                        Func_1.default.showToast("该城市不存在!");
                    }
                });
                Scroll.create();
                Scroll.debugLine("pages/City.ets(172:19)");
                Scroll.width('100%');
                Scroll.height(100);
                Scroll.scrollable(ScrollDirection.Horizontal);
                Scroll.scrollBar(BarState.Off);
                Scroll.edgeEffect(EdgeEffect.Fade);
                Row.create();
                Row.debugLine("pages/City.ets(173:21)");
                Image.create({ "id": 16777223, "type": 20000, params: [], "bundleName": "work.twradio.betterweather", "moduleName": "entry" });
                Image.debugLine("pages/City.ets(175:23)");
                Image.width(20);
                Image.height(20);
                Image.margin({ left: 10, right: 5 });
                Column.create();
                Column.debugLine("pages/City.ets(178:23)");
                Column.width('90%');
                Column.height('65%');
                Column.margin({ top: 5, left: 10 });
                Column.alignItems(HorizontalAlign.Start);
                Row.create();
                Row.debugLine("pages/City.ets(179:25)");
                Row.alignItems(VerticalAlign.Center);
                Text.create(this.getCityInfo(item).weather);
                Text.debugLine("pages/City.ets(181:27)");
                Text.fontSize(17);
                Text.width('15%');
                Text.textAlign(TextAlign.Center);
                Text.fontColor(0x2B85FF);
                Text.margin({ top: 3 });
                Text.pop();
                Text.create(this.getCityInfo(item).name + ', ');
                Text.debugLine("pages/City.ets(188:27)");
                Text.fontSize(19);
                Text.pop();
                Text.create(this.getCityInfo(item).low + '°/' + this.getCityInfo(item).high + '°');
                Text.debugLine("pages/City.ets(189:27)");
                Text.fontSize(17);
                Text.margin({ top: 2 });
                Text.fontWeight(FontWeight.Bold);
                Text.pop();
                Row.pop();
                Text.create(this.getCityInfo(item).describe);
                Text.debugLine("pages/City.ets(194:25)");
                Text.fontSize(15);
                Text.margin({ top: 7, left: 10 });
                Text.pop();
                Column.pop();
                Button.createWithChild();
                Button.debugLine("pages/City.ets(200:23)");
                Button.width(100);
                Button.height('100%');
                Button.type(ButtonType.Normal);
                Button.backgroundColor(0xFFDBEB);
                Button.onClick(() => {
                    if (this.cities.length === 1) {
                        Func_1.default.showToast("至少要包含一个城市");
                    }
                    else {
                        this.cities.splice(this.cities.indexOf(this.getCityInfo(item).name), 1);
                        this.setPreference("cities", JSON.stringify(ObservedObject.GetRawObject(this.cities))).then(async () => {
                            this.city_info = [];
                            this.ready = false;
                            await this.aboutToAppear();
                        });
                    }
                });
                Image.create({ "id": 16777225, "type": 20000, params: [], "bundleName": "work.twradio.betterweather", "moduleName": "entry" });
                Image.debugLine("pages/City.ets(201:25)");
                Image.width(28);
                Image.height(28);
                Button.pop();
                Row.pop();
                Scroll.pop();
                //if(item < this.city_info.length && this.getCityInfo(item).exist === true)
                ListItem.pop();
            }, item => item);
            ForEach.pop();
            List.pop();
        }
        If.pop();
        Column.pop();
        Row.pop();
    }
}
loadDocument(new City("1", undefined, {}));


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		var commonCachedModule = globalThis["__common_module_cache___3a4ded664851909acb9e6497578a39cd"] ? globalThis["__common_module_cache___3a4ded664851909acb9e6497578a39cd"][moduleId]: null;
/******/ 		if (commonCachedModule) { return commonCachedModule.exports; }
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		function isCommonModue(moduleId) {
/******/ 		                if (globalThis["webpackChunk_3a4ded664851909acb9e6497578a39cd"]) {
/******/ 		                  const length = globalThis["webpackChunk_3a4ded664851909acb9e6497578a39cd"].length;
/******/ 		                  switch (length) {
/******/ 		                    case 1:
/******/ 		                      return globalThis["webpackChunk_3a4ded664851909acb9e6497578a39cd"][0][1][moduleId];
/******/ 		                    case 2:
/******/ 		                      return globalThis["webpackChunk_3a4ded664851909acb9e6497578a39cd"][0][1][moduleId] ||
/******/ 		                      globalThis["webpackChunk_3a4ded664851909acb9e6497578a39cd"][1][1][moduleId];
/******/ 		                  }
/******/ 		                }
/******/ 		                return undefined;
/******/ 		              }
/******/ 		if (globalThis["__common_module_cache___3a4ded664851909acb9e6497578a39cd"] && String(moduleId).indexOf("?name=") < 0 && isCommonModue(moduleId)) {
/******/ 		  globalThis["__common_module_cache___3a4ded664851909acb9e6497578a39cd"][moduleId] = module;
/******/ 		}
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__("../../../../../../../../../Desktop/new/harmonybetterweather/entry/src/main/ets/pages/City.ets?entry");
/******/ 	_3a4ded664851909acb9e6497578a39cd = __webpack_exports__;
/******/ 	
/******/ })()
;
//# sourceMappingURL=City.js.map