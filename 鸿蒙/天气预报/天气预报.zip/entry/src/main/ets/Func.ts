import promptAction from '@ohos.promptAction';

function showToast(msg: string, time: number = 2000){
    try {
        promptAction.showToast({
            message: msg,
            duration: time,
        });
    } catch (error) {
        console.error(`showToast args error code is ${error.code}, message is ${error.message}`);
    };
}


export default { showToast };