import abilityTest from './ability.test'

export default function testsuite() {
  abilityTest()
}