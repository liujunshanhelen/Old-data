#include<stdio.h>

int main()
{
	float f;
	printf("dvv");
	return 0;
}