#include<stdio.h>
double fib[200];
void f(int n)
{
    fib[0]=1;
    fib[1]=1;
    int i=2;
  
    for(i=2;i<=n;i++)
    {
        fib[i]=fib[i-1]+fib[i-2];

    }
}
int main()
{
    int n;
    printf("input");
    scanf("%d",&n);
    f(n);
    printf("%lf", fib[n]);
    double g=(double)(fib[n-1])/(double)(fib[n]);
    printf(" g=%.8lf\n",g);
}
