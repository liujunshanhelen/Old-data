#include <stdio.h>

int main()
{
    FILE* file;
    int tmp;
    char data[1024];
    int i = 0;
    
    file = fopen("./hello.c", "r");
    while((data[i++] = fgetc(file)) != -1);
    fclose(file);

    i -= 1;
    for(int j = 0; j < i ; j += 16)
    {
        int end = j + 16;
        if(end > i)
            end = i;
        for(int k = j; k < end; k++)
        {
            if(data[k] < 0)
            {
                printf(" CH  ");
                continue;
            }
            switch(data[k])
            {
                case 10:
                    printf(" \\n  ");
                    break;
                case 32:
                    printf(" SP  ");
                    break;
                default:
                    printf(" %c   ", data[k]);
                    break;
            }
        }
        printf("\n");
        for(int k = j; k < end; k++)
        {
            if(data[k] < 0)
            {
                printf(" /   ");
                continue;
            }
            printf("%3d  ", data[k]);
        }
        printf("\n\n");
    }


}
