#include<stdio.h>
int sum(int a[], unsigned len)
{
	int i, sum = 0;
	for (int i = 0; i <= len - 1; i++)
	{
		sum++;
	}
	return sum;
}
int main()
{
	int a[5] = { 1,2,3,4,5 };
	printf("sum=%d", sum(a, 0));
	return 0;
}
