#include<stdio.h>
long f(int n)
{
    if(n==0||n==1)
      return 1;
    else 
      return f(n-1)+f(n-2);
}
int main()
{
    int n;
    printf("input n\n");
    scanf("%d",&n);
    double d=f(n)/f(n-1);
    printf("d=%.8lf",d);
    return 0;
}
